<?php $title = "Recent Tournament Games"; include("header.phtml"); ?>

<div id="text-content">

<h2>Games</h2>

<div id="subnav">
    <ul>
        <li class="active"><a href="/tourney">Recent Tournament Games</a></li>
        <li><a href="/games">Game Archive</a></li>
    </ul>
</div>


<?php include("titles/titles.html"); ?>

<p>Games are collected primarily from <a href="http://igo-kisen.hp.infoseek.co.jp/topics.html">KIN's Go Topics</a>.</p>

</div>

<?php include("footer.phtml"); ?>