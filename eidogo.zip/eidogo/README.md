EidoGo
======

EidoGo is two things:

1. A site ([eidogo.com](http://eidogo.com/)) for refining your Go techniques, viewing games, and sharing games. The source for which is here, at the top level of this repo. It includes server-side PHP code and database data.

2. An embeddable HTML/CSS/JS SGF viewer. The source for that is in the [player directory](https://github.com/jkk/eidogo/tree/master/player) of this repo. It does not depend on any server-side code or data.

