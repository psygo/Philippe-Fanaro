<?php include("header.phtml"); ?>

<div id="text-content">

<h2>Tests</h2>

<div id="player-test"></div>



</div>

<?php include("footer.phtml"); ?>
